'use strict';


/**
 * Get all products
 * Get all products
 *
 * returns List
 **/
exports.productsGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "price" : 2900,
  "imageurl" : "https://picsum.photos/id/1071/300/200",
  "count" : 10,
  "description" : "The Flying Ford Anglia was used on 3 August 1992 by Fred, George, and Ron Weasley to rescue Harry Potter, who was locked up in his room at the Dursleys' and had been unable to receive any mail from the Wizarding community as a result of Dobby's attempts to protect him.",
  "id" : "16",
  "title" : "Flying car"
}, {
  "price" : 2900,
  "imageurl" : "https://picsum.photos/id/1071/300/200",
  "count" : 10,
  "description" : "The Flying Ford Anglia was used on 3 August 1992 by Fred, George, and Ron Weasley to rescue Harry Potter, who was locked up in his room at the Dursleys' and had been unable to receive any mail from the Wizarding community as a result of Dobby's attempts to protect him.",
  "id" : "16",
  "title" : "Flying car"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get product details
 * Get product details
 *
 * productId String product ID that needs to be shown
 * returns List
 **/
exports.productsProductIdGET = function(productId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "price" : 2900,
  "imageurl" : "https://picsum.photos/id/1071/300/200",
  "count" : 10,
  "description" : "The Flying Ford Anglia was used on 3 August 1992 by Fred, George, and Ron Weasley to rescue Harry Potter, who was locked up in his room at the Dursleys' and had been unable to receive any mail from the Wizarding community as a result of Dobby's attempts to protect him.",
  "id" : "16",
  "title" : "Flying car"
}, {
  "price" : 2900,
  "imageurl" : "https://picsum.photos/id/1071/300/200",
  "count" : 10,
  "description" : "The Flying Ford Anglia was used on 3 August 1992 by Fred, George, and Ron Weasley to rescue Harry Potter, who was locked up in his room at the Dursleys' and had been unable to receive any mail from the Wizarding community as a result of Dobby's attempts to protect him.",
  "id" : "16",
  "title" : "Flying car"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

